<h1 align="center">
  Luna Token Grabber
</h1>

<div align="center">
  <img  src="https://cdn.discordapp.com/attachments/1202370899756724325/1203325922242072616/poland-flag-png-large.png?ex=65d0af98&is=65be3a98&hm=491632b9521276e87a851640c7d3121927becafd59e912e5358b17449435f31c&">
  <br>
  <img  src="https://img.shields.io/github/languages/top/Smug246/Luna-Token-Grabber?color=6d00c1">
  <img  src="https://img.shields.io/github/stars/Smug246/Luna-Token-Grabber?color=6d00c1&logoColor=6d00c1">
  <br>
  <img  src="https://img.shields.io/github/commit-activity/w/Smug246/Luna-Token-Grabber?color=6d00c1">
  <img  src="https://img.shields.io/github/last-commit/Smug246/Luna-Token-Grabber?color=6d00c1&logoColor=6d00c1">
  <br>
  <img  src="https://img.shields.io/github/issues/Smug246/Luna-Token-Grabber?color=6d00c1&logoColor=6d00c1">
  <img  src="https://img.shields.io/github/issues-closed/Smug246/Luna-Token-Grabber?color=6d00c1&logoColor=6d00c1">
  <hr  style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;"  noshade=""  size="20"  width="100%">
</div>

## Features

- Discord Info
    - Token
    - Nitro
    - Billing
    - 2FA 
    - Email
    - Phone
    - Gift Codes
    - Backup Codes

- Browser Data
    - Cookies
    - Passwords
    - History
    - Credit/Debit Cards

- Game Data
	- Minecraft Session Info
	- Roblox Cookie & Other Data

- Discord Injection
    - Sends token, password & email on user login or when user changes password

- System info
    - User
    - OS
    - System
    - Network IP
    - Wifi
    - Mac
    - Hwid
    - PC Specs
    - Screenshot

- General Functions
    - Checks if being run in a virustotal sandbox/virtual machine
    - Checks for blacklisted users, pc names, HWIDs, IPs, MACs and Processes
    - Adds file to startup
    - Anti Spam
    - Fake Error
    - Obfuscation
    - Icon
    - Low Detections
    - Bypass Token Protector
    - File Pumper
    - Self Destruct
 
<hr  style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;"  noshade=""  size="20"  width="100%">
  
## Installation

### 1. Download Python:

```
Make sure you have Python installed 3.11+ and it is added to your path
```
### 2. Download The Files:

```
Once you've downloaded the files extract the folder so it's no longer a .zip file.
```
### 3. Open The setup.bat File:

```
You dont need to install any modules opening setup.bat will install them for you. Then you need to open run.bat as administrator which will
open the gui.
```
### 4. Create A Webhook:

```
This webhook will be sent any victims you log so don't delete it once it's made. Once you've created one paste it
into the box which asks for your webhook.
```
### 5. Configurable Options:

```
Now once you've done that you can tick on the options that you want enabled and anything you don't understand you can go 
to the documentation where each option is explained.
```
### 6. What Now?

```
The .exe file will appear in the same folder where all the other files are with the name you set it as and you can now send
this to your victims.😈
```

<hr  style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;"  noshade=""  size="20"  width="100%">
  
### GUI

<div align="center">
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="https://i.imgur.com/E8tX79g.png"></img>
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="https://i.imgur.com/c1cUmZF.png"></img> 
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="https://i.imgur.com/zReVojP.png"></img>  
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="https://i.imgur.com/9u8nNbD.png"></img>
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="https://i.imgur.com/6GO5CB4.png"></img>
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="https://i.imgur.com/4DNCiAJ.png"></img>
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="https://i.imgur.com/s5f4HVs.png"></img>
</div>